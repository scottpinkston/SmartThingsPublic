# Generic-Video-Camera
Generic Video Camera Live Streaming Video in SmartThings Tile View

Install the 2 smartapps and devicetype in IDE.

Add SmartApp Connect app to your mobile install
Go into SmartApps, Generic Video Camera Connect App
Add Cameras
Either use drop down and edit in the child smartapp in IDE for your cameras
or
use the custom url to add any url to stream.
